# Datasheets

Each `<name>.pdf` has an OCR'd `<name>.md` next to it (generated with `mistral_ocr --images separate`), with figures in `<name>_images/`. Prefer reading the `.md`; fall back to the PDF for diagrams the OCR lost.

| File | Part | Ref | Role / status |
|---|---|---|---|
| ESP32-C3 | ESP32-C3 (FH4, in-package flash) | U1 | MCU |
| FUSB302B | FUSB302BMPX | U2 | USB-C PD PHY. VBUS pin abs max 28 V (fed via SW5, keep off in EPR) |
| TPD4E05U06 | TPD4E05U06DQAR | U3 | ESD on CC / D+/D- |
| ME6217 | ME6217C33M5G | U4 | 3.3 V LDO from +5V |
| LMR38010 | LMR38010FDDAR | U5 (new) | 4.2–80 V 1 A buck (FPWM), replaces MP9943 (36 V) for 48 V EPR. fsw ≈ 1.05 MHz (RT R30 = 24k), L3 10 µH, FB 120k/30k, out 2×22 µF |
| LMR36510 | LMR36510ADDAR | — | 65 V alternative, not used (different pinout from LMR38010) |
| INA238-Q1 | INA238AQDGSRQ1 | U6 (new) | 85 V 16-bit current/power monitor, replaces INA226 (36 V). Pin-for-pin with INA226 (VSSOP-10); register map differs. Use ADCRANGE = ±163.84 mV (10 mΩ × 5 A = 50 mV). Parts already in stock at home |
| INA237 | INA237AIDGSR | — | 85 V alternative, not used |
| INA226 | INA226 | U6 (old) | kept for register-map comparison when porting firmware |
| SI7469DP | SI7469DP-T1-GE3 | Q1 (new) | −80 V P-MOSFET output switch, replaces IRF7416 (−30 V) |
| MMBT5551LT1G | MMBT5551 | Q2 (new) | 160 V NPN gate driver, replaces MMBT3904 (40 V) |
| BZX84C15LT1G | BZX84C15 | D2 | Q1 gate-source clamp |
| MBR230LSFT1G | MBR230LSFT1G | D3 | J2 VBUS → +5V OR-ing diode |
| SSD1306 | SSD1306 | OLED1 | display controller |
| USB4125-GF-A | GCT USB4125 | J1 | power USB-C. Rated 20 V / 3 A only — not EPR-rated |
| USB4105-GF-A | GCT USB4105 | J2 | data USB-C |
| GRM32EC72A106KE05 | Murata GRM32EC72A106KE05L | C15 (new) | 10 µF 100 V X7R 1210 input cap (file is a full Murata catalog) |
