import collections, heapq, itertools, json, math
from pathlib import Path
board = json.loads(Path('pd-board.json').read_text())
devs = {d['designator']:d for d in board['devices']}
pads = collections.defaultdict(list)
for d in devs.values():
    for p in d['pads']:
        pads[p['pad']].append(p)
def xy(v):
    return v['x'],v['y']
def anchor(p):
    return (p['pad'],*xy(p['position'])) if p.get('pad') else p.get('via') or p.get('junction') or p.get('board_pad')
graphs=collections.defaultdict(lambda:collections.defaultdict(list))
for t in board['traces']:
    a,z=(anchor(t[e]) for e in ['from','to'])
    length=math.dist(*(xy(t[e]['position']) for e in ['from','to']))
    graphs[t['net']][a].append((z,length,t))
    graphs[t['net']][z].append((a,length,t))
def path(a,b):
    options=[]
    for p,q in itertools.product(pads[a],pads[b]):
        if p['net'] != q['net']: continue
        net=p['net']; g=graphs[net]; a1,b1=anchor(p),anchor(q)
        distance=math.dist(xy(p['position']),xy(q['position']))
        ticket=itertools.count()
        visited=set()
        queue=[(0,next(ticket),a1,[])]
        while queue:
            dist,_,v,route=heapq.heappop(queue)
            if v in visited:continue
            visited.add(v)
            if v==b1:
                options.append((dist,distance,route));break
            for z,l,t in g.get(v,[]):
                if z not in visited:
                    heapq.heappush(queue,(dist+l,next(ticket),z,route+[(z,t['layer'],t['width'])]))
    if not options:
        return (round(min(math.dist(xy(p['position']),xy(q['position'])) for p,q in itertools.product(pads[a],pads[b])),2), None)
    dist,gap,route=min(options,key=lambda o:o[0])
    return (round(gap,2),round(dist,2),list(dict.fromkeys(l for _,l,_ in route)),sum(isinstance(v,str) and any(w['uuid']==v for w in board['vias']) for v,_,_ in route),sorted(set(w for _,_,w in route)))
cases={
'OLED': [('OLED1.2','C23.2'),('OLED1.3','C23.1'),('OLED1.4','C24.2'),('OLED1.5','C24.1'),('OLED1.6','C25.2'),('OLED1.9','C26.2'),('OLED1.11','C26.2'),('OLED1.15','C26.2'),('OLED1.14','R22.2'),('OLED1.14','C27.1'),('OLED1.14','D4.2'),('OLED1.26','R21.2'),('OLED1.27','C22.1'),('OLED1.28','C21.1'),('OLED1.29','C21.2'),('OLED1.29','C22.2'),('OLED1.1','C23.1'),('OLED1.18','U1.14'),('OLED1.19','U1.15')],
'Buck':[('U5.3','C15.2'),('U5.3','C16.2'),('U5.1','C15.1'),('U5.1','C16.1'),('U5.4','R30.2'),('U5.5','R14.1'),('U5.5','R16.2'),('U5.7','C18.1'),('U5.8','C18.2'),('U5.8','L3.1'),('L3.2','C33.2'),('L3.2','C34.2'),('U5.2','R13.2')],
'MCU':[('U1.30','R9.1'),('R9.2','Y1.1'),('Y1.1','C1.1'),('U1.29','Y1.3'),('Y1.3','C2.2'),('U1.1','C3.1'),('U1.1','L1.1'),('L1.2','C31.1'),('C31.1','AE1.1'),('U1.2','C12.2'),('U1.3','C12.2'),('U1.31','C7.2'),('U1.32','C7.2'),('U1.17','C6.1'),('U1.17','C8.2'),('U1.11','C11.2'),('U1.18','C32.2'),('U1.7','C5.1'),('U1.7','R5.2'),('U1.8','C4.2')],
'USB PD':[('J2.A6','U3.5'),('J2.B6','U3.5'),('J2.A7','U3.4'),('J2.B7','U3.4'),('J2.A5','R1.1'),('J2.B5','R8.2'),('J1.A5','U2.10'),('J1.B5','U2.1'),('U2.3','C29.2'),('U2.12','C30.2'),('U2.2','R10.1'),('R10.2','C4.2'),('J2.A4','D3.1')],
'LDO':[('U4.1','C13.2'),('U4.5','C9.2'),('U4.5','C10.2'),('U4.5','C14.2')],
'Sense/Power':[('U6.6','C19.2'),('U6.9','R17.2'),('U6.10','R17.3'),('U6.8','R17.1'),('Q1.4','D2.1'),('Q1.4','R27.1'),('Q1.1','D2.3'),('Q1.5','J3.2'),('R17.1','Q1.1'),('R17.4','J1.A9'),('R17.1','J3.1'),('Q2.1','R18.2'),('Q2.1','R19.2'),('Q2.2','R29.1')],
}
for name,pairs in cases.items():
    print(name)
    for a,b in pairs: print(a,b,*path(a,b))
print('OLED actual pads:',[(i,xy(pads[f'OLED1.{i}'][0]['position'])) for i in [1,2,3,4,5,6,9,11,14,15,26,27,28,29,30]])
print('Nearby OLED vias:')
for v in board['vias']:
    x,y=xy(v['position'])
    if 143<=x<=167 and -116<=y<=-104:
        print(v['net'],(x,y))
