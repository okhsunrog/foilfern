"""Compare saved ADC geometry and report the rejected alternative separately."""
import json,math,heapq,sys
from pathlib import Path
sys.dont_write_bytecode=True
p=Path(__file__).parent
def load(f):
 d=json.load(open(p/f))
 if 'response' in d:d=d['response']['result']['structuredContent']
 return d.get('result',d)
def dump(f,d):(p/f).write_text(json.dumps(d,indent=2))
def xy(d):return list(d.values())
def length(t):return math.dist(xy(t['from']['position']),xy(t['to']['position']))
def key(e):return e.get('pad_uuid') or e.get('via') or e.get('junction') or e.get('board_pad')
def ground(b):
 vs={v['uuid']:v for v in b['vias'] if v['net']=='GND'};start=next(q['uuid'] for d in b['devices'] for q in d['pads'] if q['pad']=='C4.1');graph={}
 for t in b['traces']:
  if t['net']!='GND':continue
  a,z=key(t['from']),key(t['to'])
  for x,y in [(a,z),(z,a)]:graph.setdefault(x,[]).append((y,length(t),t['uuid']))
 queue=[(0,start,[])];seen=set()
 while queue:
  dist,n,route=heapq.heappop(queue)
  if n in seen:continue
  seen.add(n)
  if n in vs:return {'length_mm':dist,'via':n,'via_position':vs[n]['position'],'traces':route,'scope':'Shortest explicit C4 ground lead to a via; plane return to MCU is excluded.'}
  for z,c,id in graph.get(n,[]):heapq.heappush(queue,(dist+c,z,route+[id]))
 raise ValueError('No ground via path')
a=load('baseline-board_get.json');s=load('direct-board_get.json');w=load('whole-preview-geometry.json');request=json.load(open(p/'04-direct-input.json'))
out={n:{'trace_segments':len(b['traces']),'vias':len(b['vias']),'trace_length_mm':sum(length(t) for t in b['traces']),'c4_ground_lead':ground(b)} for n,b in [('baseline',a),('selected',s),('whole_rejected_preview',w)]}
for field in ['traces','vias']:
 aa={v['uuid']:v for v in a[field]};ss={v['uuid']:v for v in s[field]};removed=sorted(aa.keys()-ss.keys());added=sorted(ss.keys()-aa.keys());assert removed==sorted(request.get('remove_'+field,[]))
 def norm(v):return {k:q for k,q in v.items() if k!='segment'}
 assert all(norm(aa[k])==norm(ss[k]) for k in aa.keys()&ss.keys());out[field]={'removed':removed,'added':added,'retained_geometry_preserved':True}
for k in ['copper_layers','holes','other_polygons','outlines','polygons','zones','thickness']:assert a[k]==s[k],k
assert [{k:v for k,v in q.items() if k!='fragments'} for q in a['planes']]==[{k:v for k,v in q.items() if k!='fragments'} for q in s['planes']]
da={d['designator']:d for d in a['devices']};ds={d['designator']:d for d in s['devices']};assert all(d==ds[n] for n,d in da.items() if n!='C4')
out['placements']=[{'component':'C4','before':{k:da['C4'][k] for k in ['position','rotation','side']},'after':{k:ds['C4'][k] for k in ['position','rotation','side']}}]
out['mechanical_and_plane_settings_preserved']=True
out['netlist_byte_identical']=(p/'selected/circuit/circuit.lp').read_bytes()==Path('/workspace/esp-pd-sink/kelvin-review/selected/circuit/circuit.lp').read_bytes();assert out['netlist_byte_identical']
out['drc_messages_identical']=load('direct-drc_run.json')['messages']==load('baseline-drc_run.json')['messages'];assert out['drc_messages_identical']
assert load('direct-erc_run.json')['messages']==load('baseline-erc_run.json')['messages']
refs={}
for l in ['inner1','inner2']:
 r=load('direct-'+l+'-routing_preview.json')['reference_coverage'];applied=load('direct-'+l+'-reference_coverage.json')['coverage'];assert r['after']==applied
 bn={q['net']:q for q in r['before']['nets']};an={q['net']:q for q in applied['nets']};nets=['CC1','CC2','D+','D-','ANT','Net-(AE1-FEED)','Net-(U6-Vin+)','Net-(U6-Vin-)','Net-(U2-VBUS)'];assert all(bn[n]==an[n] for n in nets)
 refs[l]={'protected_nets_unchanged':True,'applied_equals_preview':True,'before':r['before'],'after':applied}
 print(l,'ADC coverage',[(stage,[(q['checked_mm'],q['gaps']['length_mm']) for q in r[stage]['nets'] if q['net']=='ADC_VBUS']) for stage in ['before','after']])
dump('geometry-comparison.json',out);dump('reference-comparison.json',refs);print(json.dumps({k:out[k] for k in ['baseline','selected','whole_rejected_preview']},indent=2))
