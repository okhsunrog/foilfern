import sys,json,base64
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent));from workflow import p,save,call,protected
r=json.load(open(p/'direct-inner1-routing_preview.json'))['result'];assert r['validation']['acceptable'] and not r['stale'] and r['next_offset'] is None
save('direct','routing_apply',{'candidate':r['candidate'],'expected_revision':r['base_revision']})
for tool in ['erc_run','drc_run','unrouted','board_get']:save('direct',tool)
for l in ['inner1','inner2']:save('direct-'+l,'reference_coverage',{'reference':{'signal_nets':protected+['ADC_VBUS','Net-(U2-VBUS)'],'reference_net':'GND','reference_layer':l,'gap_limit':200}})
save('direct-ground','plane_diagnose',{'plane':'0e53fe96-8895-4f03-9f0a-ae0f9bbec798','probe':{'x':112.95,'y':-117.2}})
save('direct','export_fabrication',{'output_dir':str(p/'fabrication/direct-foilfern')})
for side in ['top','bottom']:
 raw=call('render',{'target':'board','side':side,'width':1800,'height':1300})
 for c in raw['response']['result']['content']:
  if c['type']=='image':(p/('direct-board-'+side+'.png')).write_bytes(base64.b64decode(c['data']))
 print('render',side,round(raw['seconds'],3),flush=True)
for tool in ['project_save','history','project_close']:save('direct',tool)
