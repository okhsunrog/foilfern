import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/esp-pd-sink');from call import run,call,envelope
p=Path(__file__).parent
protected=['CC1','CC2','D+','D-','ANT','Net-(AE1-FEED)','Net-(U6-Vin+)','Net-(U6-Vin-)']
def save(label,name,args=None):
 e=run(name,args);(p/f'{label}-{name}.json').write_text(json.dumps(e,indent=2));assert not e.get('error'),e;return e
if __name__=='__main__':
 for name in ['server_info','project_summary','history','schematic_list','component_list','board_get','erc_run','drc_run','unrouted']:save('baseline',name)
 for c in ['C4','R10','R11','SW5','U1','U2']:save(c,'component_get',{'component':c})
 r=call('',{},'tools/list');(p/'tools.json').write_text(json.dumps(r,indent=2))
