import subprocess,json,os,hashlib,shutil
from pathlib import Path
p=Path(__file__).parent
env=dict(os.environ,LIBREPCB_SUPPRESS_DEPRECATION_WARNINGS='1')
for variant in ['selected']:
 r=subprocess.run(['librepcb-cli','open-project','--erc','--drc',str(p/variant/'ESP-PD-Sink.lpp')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT)
 (p/f'{variant}-upstream-check.txt').write_bytes(r.stdout);(p/f'{variant}-upstream-check-exit.txt').write_text(str(r.returncode)+'\n');assert r.returncode==1,r.stdout.decode();print(variant,'upstream check',r.returncode,flush=True)
 if variant=='selected':
  r=subprocess.run(['librepcb-cli','open-project','--export-pcb-fabrication-data',str(p/variant/'ESP-PD-Sink.lpp')],env=env,stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(p/'selected-upstream-export.txt').write_bytes(r.stdout);assert r.returncode==0,r.stdout.decode()
  up=p/'fabrication/upstream';up.mkdir(parents=True,exist_ok=True)
  for f in (p/'selected/output').rglob('*'):
   if f.suffix in ['.gbr','.drl']:shutil.copy2(f,up/f.name)
  ff=p/'fabrication/direct-foilfern'
  assert {f.name for f in ff.iterdir()}=={f.name for f in up.iterdir()};assert len(list(ff.iterdir()))==13
  def normalized(f):return b'\n'.join(line for line in f.read_bytes().splitlines() if not any(k in line for k in [b'TF.GenerationSoftware,',b'TF.CreationDate,',b'TF.MD5,']))
  comparison=[{'file':f.name,'equal_excluding_generator_creation_date_checksum':normalized(f)==normalized(up/f.name),'foilfern_sha256':hashlib.sha256(f.read_bytes()).hexdigest(),'upstream_sha256':hashlib.sha256((up/f.name).read_bytes()).hexdigest()} for f in sorted(ff.iterdir())]
  (p/'fabrication-comparison.json').write_text(json.dumps(comparison,indent=2));print('fabrication matches',sum(c['equal_excluding_generator_creation_date_checksum'] for c in comparison),flush=True);assert all(c['equal_excluding_generator_creation_date_checksum'] for c in comparison)
