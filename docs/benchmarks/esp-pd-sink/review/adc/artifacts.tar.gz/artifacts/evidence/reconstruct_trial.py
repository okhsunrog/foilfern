"""Read-only copper graph reconstruction from a rejected MCP preview.

Never applies mutations or writes native files. Plane coverage/DRC must come
from MCP's preview; this graph supports centerline measurement and review plots.
"""
import json,copy
from pathlib import Path
p=Path(__file__).parent
b=copy.deepcopy(json.load(open(p/'whole-final-placed-board_get.json'))['result'])
r=json.load(open(p/'whole-inner1-routing_preview.json'))['result'];assert not r['validation']['acceptable'] and r['next_offset'] is None
pads={q['uuid']:q for d in b['devices'] for q in d['pads']};vias={v['uuid']:v for v in b['vias']};traces={t['uuid']:t for t in b['traces']};junctions={e['junction']:e['position'] for t in b['traces'] for e in [t['from'],t['to']] if 'junction' in e};nets={v['segment']:v['net'] for v in b['traces']+b['vias']}
netids={pads[a]['net'] for a in pads}
# Native net UUID -> display name from source project summary component pin map.
base=json.load(open(p/'baseline-component_list.json'))['result']
net_names={}
# board net names are resolved from the circuit's UUID/name definitions.
import re
circuit=Path('/workspace/esp-pd-sink/kelvin-review/selected/circuit/circuit.lp').read_text()
net_names=dict(re.findall(r'\(net ([\w-]+) \(auto (?:true|false)\) \(name "([^"]+)"\)',circuit))
newtraces={};newvias={}
def mm(q):return {k:v/1e6 for k,v in q.items()}
for m in r['mutations']:
 for kind,arg in m['Board'].items():
  if kind=='AddNetSegment':
   s=arg['segment'];sid=s['uuid'];nets[sid]=net_names[s['net']];items={k:list(s[k].values()) for k in ['traces','vias','junctions']}
  elif kind=='AddNetSegmentElements':sid=arg['segment']['segment'];items=arg['elements']
  else:continue
  for q in items['junctions']:junctions[q['uuid']]=mm(q['position'])
  for q in items['vias']:newvias[q['uuid']]=(q,sid)
  for q in items['traces']:newtraces[q['uuid']]=(q,sid)
for id,(q,sid) in newvias.items():
 vias[id]={'uuid':id,'segment':sid,'net':nets[sid],'position':mm(q['position']),'drill':q['drill_diameter']/1e6,'size':q['size']/1e6,'effective_drill':q['drill_diameter']/1e6,'effective_size':q['size']/1e6,'start_layer':q['start_layer'],'end_layer':q['end_layer']}
def endpoint(e):
 kind,arg=next(iter(e.items()))
 if kind=='FootprintPad':
  q=pads[arg['pad']];return {'pad':q['pad'],'pad_uuid':q['uuid'],'position':q['position']}
 if kind=='Via':return {'via':arg,'position':vias[arg]['position']}
 if kind=='Junction':return {'junction':arg,'position':junctions[arg]}
 raise ValueError(kind)
for id,(q,sid) in newtraces.items():traces[id]={'uuid':id,'segment':sid,'net':nets[sid],'layer':q['layer'],'width':q['width']/1e6,'from':endpoint(q['p1']),'to':endpoint(q['p2'])}
b['traces']=list(traces.values());b['vias']=list(vias.values());b['air_wires']=[]
b['evidence_source']='Read-only trace graph reconstructed from rejected routing_preview plus placed board_get; not an accepted/native board. Coverage and 34-error DRC come from MCP preview.'
(p/'whole-preview-geometry.json').write_text(json.dumps({'result':b},indent=2));print(len(traces),len(vias),'reconstructed trial graph only')
