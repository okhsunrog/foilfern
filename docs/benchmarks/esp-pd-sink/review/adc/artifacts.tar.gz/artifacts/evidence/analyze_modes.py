"""Ideal divider calculations and explicit SW5 connectivity, not circuit simulation."""
import json,math
from pathlib import Path
p=Path(__file__).parent;b=json.load(open(p/'baseline-board_get.json'))['result'];ds={d['designator']:d for d in b['devices']}
refs=['SW5.1','SW5.2','U2.2','R10.1','R10.2','R11.1','R11.2','C4.1','C4.2','U1.8']
pads={q['pad']:q for d in b['devices'] for q in d['pads']}
assert pads['SW5.1']['net']==pads['R10.1']['net']==pads['U2.2']['net']=='Net-(U2-VBUS)'
assert pads['SW5.2']['net']=='VBUS'
assert all(pads[a]['net']=='ADC_VBUS' for a in ['R10.2','R11.1','C4.2','U1.8'])
assert pads['R11.2']['net']==pads['C4.1']['net']=='GND'
values={n:json.load(open(p/(n+'-component_get.json')))['result']['value'] for n in ['R10','R11','C4']}
assert values=={'R10':'100K','R11':'4.7k','C4':'0.1 uF'},values
rh,rl,c=100000.,4700.,1e-7;ratio=rl/(rh+rl);rth=rh*rl/(rh+rl)
r={'scope':'Ideal linear divider, ideal closed/open SPST, ideal voltage source and unloaded ADC/U2 inputs. Values/tolerances, leakage, parasitics, sampling dynamics and protection not simulated. No electrical ratings inferred.', 'values_from_component_get':values,'pins':{a:{'component_uuid':ds[a.split('.')[0]]['component'],'footprint_pad_uuid':pads[a]['uuid'],'signal':pads[a]['signal'],'net':pads[a]['net']} for a in refs},'closed':{'connection':'VBUS -> SW5.2 -> closed contact -> SW5.1 -> U2.2 and R10.1','ratio':ratio,'thevenin_ohm':rth,'tau_seconds':rth*c,'pole_hz':1/(2*math.pi*rth*c),'five_tau_seconds':5*rth*c,'examples':[{'VBUS_V':v,'ADC_V':v*ratio,'divider_current_A':v/(rh+rl),'R10_V':v*(1-ratio),'R10_W':(v/(rh+rl))**2*rh,'R11_W':(v/(rh+rl))**2*rl} for v in [5,20,28,48]],'FUSB302B_VBUS_absolute_max_V':28,'rating_source':'HANDOFF.md and https://www.onsemi.com/pdf/datasheet/fusb302b-d.pdf; absolute maximum is not an operating target.'},'open':{'connection':'Main VBUS disconnected from U2.2/R10.1; R11 remains between ADC and GND. ADC does not measure main VBUS in this mode.','ideal_steady_state_ADC_V':0,'ideal_steady_state_U2_VBUS_V':0,'ideal_C4_discharge_tau_seconds':rl*c,'qualification':'Zero assumes no other injection or input bias. Real U2/ADC leakage, switch leakage, power sequencing and transient voltage require validation; SW5 open is not a complete 48 V qualification.'}}
(p/'sw5-mode-review.json').write_text(json.dumps(r,indent=2));print(json.dumps(r['closed'],indent=2))
