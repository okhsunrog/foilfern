import json,shutil,hashlib,tarfile,subprocess,os,re
from pathlib import Path
p=Path(__file__).parent;repo=Path('/workspace/foilfern');docs=repo/'docs/benchmarks/esp-pd-sink/review/gate'
def copy(src,dest):dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
for name in ['baseline-measurements.json','diode-measurements.json','selected-measurements.json','geometry-comparison.json','reference-comparison.json','plane-comparison.json','power-region-comparison.json','baseline-fabrication-comparison.json','fabrication-comparison.json','intent.json','measure_gate.py','compare_copper.py','plot_region.py','baseline-region.png','diode-region.png','selected-region.png','board-top.png','board-bottom.png']:copy(p/name,docs/name)
copy(p/'03-compact-input.json',docs/'selected-input.json');copy(p/'01-diode-input.json',docs/'diode-input.json')
root=p/'delivery/artifacts';root.mkdir(parents=True,exist_ok=True)
source=Path('/workspace/esp-pd-sink/adc-review/selected');original=(source/'circuit/circuit.lp').read_bytes()
for name,src in [('input-adc',source),('diode-only',p/'local'),('selected',p/'selected')]:
 assert (src/'circuit/circuit.lp').read_bytes()==original
 shutil.copytree(src,root/'native'/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('output','*.lock','*.user.lp'))
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.json','.txt','.py','.png']:copy(f,root/'evidence'/f.name)
shutil.copytree(p/'fabrication',root/'fabrication',dirs_exist_ok=True)
for name in ['session']:
 for f in (p/name).glob('*.json'):
  r=json.load(open(f))
  if r.get('request',{}).get('params',{}).get('name')!='render':copy(f,root/name/f.name)
 for f in (p/name).glob('*.stderr'):copy(f,root/name/f.name)
copy(docs/'REPORT.md',root/'REPORT.md')
manifest={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(root.rglob('*')) if f.is_file() and f.name!='SHA256.json'}
(root/'SHA256.json').write_text(json.dumps(manifest,indent=2));archive=docs/'artifacts.tar.gz'
with tarfile.open(archive,'w:gz') as t:t.add(root,arcname='artifacts')
v=p/'delivery-verify';v.mkdir(exist_ok=True)
with tarfile.open(archive) as t:t.extractall(v,filter='data')
a=v/'artifacts';assert all(hashlib.sha256((a/n).read_bytes()).hexdigest()==h for n,h in json.load(open(a/'SHA256.json')).items())
r=subprocess.run(['librepcb-cli','open-project','--erc','--drc',str(a/'native/selected/ESP-PD-Sink.lpp')],env=dict(os.environ,LIBREPCB_SUPPRESS_DEPRECATION_WARNINGS='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(p/'delivery-reopen.txt').write_bytes(r.stdout)
assert r.returncode==1 and b'Non-approved messages: 12' in r.stdout and b'Non-approved messages: 0' in r.stdout
for link in re.findall(r'\]\(([^)]+)\)',(docs/'REPORT.md').read_text()):
 if '://' not in link:assert (docs/link).exists(),link
print('Verified',len(manifest),'archived files and reopened extracted selected native project; archive bytes',archive.stat().st_size)
