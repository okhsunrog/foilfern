import json
from pathlib import Path
p=Path(__file__).parent;b=json.load(open(p/'baseline-board_get.json'))['result']
def pt(x,y):return {'x':x,'y':y}
def t(a,z,points=(),width=.2):
 r={'from':a,'to':z,'layer':'top','width':width}
 if points:r['points']=[pt(*q) for q in points]
 return r
source_tail=['4662c03f-a2e5-4e66-9125-d0a1f1077a32','8013c46d-8ee2-461d-8a07-e982b597a8c1','bb5f4717-dc33-4083-8872-5309e665a4ed','b83715f0-3fc9-4f20-ba14-9c12444a4b60','c870b066-06fb-4eb8-9130-3f1222e10a9c','d978483d-e9bb-49e1-bed6-f56acec357f9','f93f53df-cfb4-436f-87f4-80a6e225a00f']
clamp=[t('D2.1','Q1.4',[(133.33,-142.95)]),t('D2.3','Q1.3',[(129.7625,-139.635)],.4)]
a={'placements':[{'component':'D2','position':pt(130.7,-142),'rotation':180}], 'remove_traces':source_tail+['04ed683d-756c-4b9c-92ac-b97dd3d2f4d8','c3e6ae1b-3ff1-4839-be64-8f9d2b068e98'],'traces':clamp+[t('6aee5988-9201-474f-b415-803909dffdb1','3e871c64-dbeb-4005-b778-cbfdf353c4c9',[(132.4625,-132.25)])]}
(p/'01-diode-input.json').write_text(json.dumps(a,indent=2))
keep={'4d37dd7f-2faa-45bd-a2dc-ef0e40c3e313','3c47e694-a801-44eb-bf1d-d06896b6bd28','86602014-f4bf-424b-9e91-8ba02f7c7f0a','cd45343f-ac3d-4d88-a1c6-e826a1dc8c71','7280eb8f-c7aa-4e43-84f4-1fedd798fd47','dbd3b2d3-f401-4ba2-8f24-ba7182a5a8d4'}
r={'placements':a['placements']+[{'component':'R20','position':pt(130.7,-145.6),'rotation':0}], 'remove_traces':sorted(set(source_tail+['39f80aab-0660-4fe8-aa1b-bb74f755f004','c57c3877-0c0e-4a4d-8cda-24423b2f4581']+[v['uuid'] for v in b['traces'] if v['net']=='Net-(D2-A)' and v['uuid'] not in keep])), 'traces':clamp+[t('R20.2','D2.1'),t('R20.1','D2.3',[(129.7625,-145.6)],.4),t('267434a2-cd83-4c5e-b352-f5fef78a4b9d','7e60fd8b-cb2a-4d05-828b-3924646c21b4',[(130.6,-133.91)],.4)]}
(p/'02-pair-input.json').write_text(json.dumps(r,indent=2));print('Requests',len(a['remove_traces']),len(r['remove_traces']))
for d in b['devices']:
 if d['designator'] in ['C33','C34']:print(d['designator'],[(q['position'],q['size'],q['net']) for q in d['pads']])
