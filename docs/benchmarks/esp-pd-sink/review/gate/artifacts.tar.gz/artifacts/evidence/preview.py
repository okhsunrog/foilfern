import json,sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent));from workflow import p,save,protected
name=sys.argv[1];source=sys.argv[2]
r=json.load(open(p/source))
if 'response' in r:r=r['response']['result']['structuredContent']
r=r['result'];assert r['validation']['acceptable']
for l in ['inner1','inner2']:save(name+'-'+l,'routing_preview',{'candidate':r['candidate'],'limit':200,'reference':{'signal_nets':protected+['ADC_VBUS','Net-(D2-A)'],'reference_net':'GND','reference_layer':l,'gap_limit':200}})
