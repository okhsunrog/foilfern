import json,sys,shutil
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent));from workflow import p,save
b=json.load(open(p/'baseline-board_get.json'))['result']
for q in b['planes']:save('baseline-full-plane-'+q['uuid'],'plane_diagnose',{'plane':q['uuid'],'limit':64})
r=json.load(open(p/'diode-inner1-routing_preview.json'))['result'];assert r['validation']['acceptable'] and not r['stale'] and r['next_offset'] is None
save('diode','routing_apply',{'candidate':r['candidate'],'expected_revision':r['base_revision']})
for tool in ['erc_run','drc_run','unrouted','board_get','project_save','history','project_close']:save('diode',tool)
shutil.copytree('/workspace/esp-pd-sink/adc-review/selected',p/'selected',ignore=shutil.ignore_patterns('output','*.lock','*.user.lp'))
save('selected-open','project_open',{'path':str(p/'selected/ESP-PD-Sink.lpp')})
for tool in ['project_summary','history','schematic_list','component_list','board_get']:save('selected-open',tool)
r=json.load(open(p/'03-compact-input.json'));r['expected_revision']=0;save('selected','routing_copper_prepare',r)
