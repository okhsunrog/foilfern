import sys,json
from pathlib import Path
sys.path.insert(0,'/workspace/esp-pd-sink');from call import run,call,envelope
p=Path(__file__).parent
protected=['CC1','CC2','D+','D-','ANT','Net-(AE1-FEED)','Net-(U6-Vin+)','Net-(U6-Vin-)']
def save(label,name,args=None):
 e=run(name,args);(p/f'{label}-{name}.json').write_text(json.dumps(e,indent=2));assert not e.get('error'),e;return e
if __name__=='__main__':
 for tool in ['server_info','project_summary','history','schematic_list','component_list','board_get','erc_run','drc_run','unrouted']:save('baseline',tool)
 for c in ['Q1','Q2','D2','R20','R27','J3']:save(c,'component_get',{'component':c})
