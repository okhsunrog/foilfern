"""Geometry, reference and power-plane preservation checks for gate-clamp review."""
import json,math,sys
from compare_copper import primitives, drill_primitives
from pathlib import Path
sys.dont_write_bytecode=True
p=Path(__file__).parent
def load(f):
 d=json.load(open(p/f))
 if 'response' in d:d=d['response']['result']['structuredContent']
 return d.get('result',d)
def dump(f,d):(p/f).write_text(json.dumps(d,indent=2))
def stats(b):return {'trace_segments':len(b['traces']),'vias':len(b['vias']),'trace_length_mm':sum(math.dist(list(t['from']['position'].values()),list(t['to']['position'].values())) for t in b['traces'])}
a=load('baseline-board_get.json');s=load('selected-board_get.json');d=load('diode-board_get.json');request=json.load(open(p/'03-compact-input.json'))
out={n:stats(b) for n,b in [('baseline',a),('diode_only',d),('selected',s)]}
for field in ['traces','vias']:
 aa={q['uuid']:q for q in a[field]};ss={q['uuid']:q for q in s[field]};removed=sorted(aa.keys()-ss.keys());added=sorted(ss.keys()-aa.keys());assert removed==sorted(request.get('remove_'+field,[]))
 def norm(q):return {k:v for k,v in q.items() if k!='segment'}
 assert all(norm(aa[k])==norm(ss[k]) for k in aa.keys()&ss.keys())
 out[field]={'removed':removed,'added':added,'retained_geometry_preserved':True}
for field in ['copper_layers','holes','other_polygons','outlines','polygons','zones','thickness']:assert a[field]==s[field],field
assert [{k:v for k,v in q.items() if k!='fragments'} for q in a['planes']]==[{k:v for k,v in q.items() if k!='fragments'} for q in s['planes']]
da={q['designator']:q for q in a['devices']};ds={q['designator']:q for q in s['devices']};assert all(q==ds[n] for n,q in da.items() if n not in ['D2','R20'])
out['placements']=[{'designator':n,'before':{k:da[n][k] for k in ['position','rotation','side']},'after':{k:ds[n][k] for k in ['position','rotation','side']}} for n in ['D2','R20']]
out['mechanical_and_plane_settings_preserved']=True
original=Path('/workspace/esp-pd-sink/adc-review/selected/circuit/circuit.lp').read_bytes();out['netlist_byte_identical']=all((p/n/'circuit/circuit.lp').read_bytes()==original for n in ['local','selected']);assert out['netlist_byte_identical']
for n in ['diode','selected']:
 assert load(n+'-drc_run.json')['messages']==load('baseline-drc_run.json')['messages']
 assert load(n+'-erc_run.json')['messages']==load('baseline-erc_run.json')['messages']
out['drc_messages_identical']=True
refs={}
for l in ['inner1','inner2']:
 r=load('selected-'+l+'-routing_preview.json')['reference_coverage'];applied=load('selected-'+l+'-reference_coverage.json')['coverage'];assert r['after']==applied
 bn={q['net']:q for q in r['before']['nets']};an={q['net']:q for q in applied['nets']};nets=['CC1','CC2','D+','D-','ANT','Net-(AE1-FEED)','Net-(U6-Vin+)','Net-(U6-Vin-)','ADC_VBUS'];assert all(bn[n]==an[n] for n in nets)
 refs[l]={'protected_nets_unchanged':True,'applied_equals_preview':True,'before':r['before'],'after':applied}
planes=[]
for q in a['planes']:
 before=load('baseline-full-plane-'+q['uuid']+'-plane_diagnose.json');after=load('selected-plane-'+q['uuid']+'-plane_diagnose.json');assert before['next_offset'] is None and after['next_offset'] is None
 same=before['fragments']==after['fragments']
 planes.append({'uuid':q['uuid'],'net':q['net'],'layer':q['layer'],'fragment_summaries_equal':same,'before':before,'after':after})
 if q['net'] in ['VBUS','VOUT','VMOS']:assert same,(q['net'],q['layer'])
proof=[]
for f in sorted((p/'fabrication/baseline-foilfern').iterdir()):
 other=p/'fabrication/selected-foilfern'/f.name
 def normalized(q):return b'\n'.join(line for line in q.read_bytes().splitlines() if not any(k in line for k in [b'TF.GenerationSoftware,',b'TF.CreationDate,',b'TF.MD5,']))
 same=normalized(f)==normalized(other)
 row={'file':f.name,'equal_excluding_generator_creation_date_checksum':same}
 if any(k in f.name for k in ['COPPER-IN1','COPPER-IN2','COPPER-BOTTOM']):
  physical=primitives(f)==primitives(other);row['canonical_copper_primitives_equal']=physical;assert physical,f.name
 if 'DRILLS' in f.name:
  physical=drill_primitives(f)==drill_primitives(other);row['canonical_drill_primitives_equal']=physical;assert physical,f.name
 if 'OUTLINES' in f.name:assert same,f.name
 proof.append(row)
out['power_copper_preserved']={'VBUS_VMOS_retained_traces_and_vias':True,'power_fragment_summaries_equal':True,'unchanged_fabrication_layers_and_drills':True}
dump('geometry-comparison.json',out);dump('reference-comparison.json',refs);dump('plane-comparison.json',planes);dump('baseline-fabrication-comparison.json',proof)
print(json.dumps({k:out[k] for k in ['baseline','diode_only','selected']},indent=2));print('Power plane areas/bounds/counts preserved; changes:',[(q['net'],q['layer']) for q in planes if not q['fragment_summaries_equal']])
