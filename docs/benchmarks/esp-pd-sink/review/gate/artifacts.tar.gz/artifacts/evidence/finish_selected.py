import sys,json,base64
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent));from workflow import p,save,call,protected
r=json.load(open(p/'selected-inner1-routing_preview.json'))['result'];assert r['validation']['acceptable'] and not r['stale'] and r['next_offset'] is None
save('selected','routing_apply',{'candidate':r['candidate'],'expected_revision':r['base_revision']})
for tool in ['erc_run','drc_run','unrouted','board_get']:save('selected',tool)
for l in ['inner1','inner2']:save('selected-'+l,'reference_coverage',{'reference':{'signal_nets':protected+['ADC_VBUS','Net-(D2-A)'],'reference_net':'GND','reference_layer':l,'gap_limit':200}})
b=json.load(open(p/'selected-board_get.json'))['result']
for q in b['planes']:save('selected-plane-'+q['uuid'],'plane_diagnose',{'plane':q['uuid'],'limit':64})
for name,x,y in [('return-entry',129.7625,-139.635),('q1-source',133.33,-139.635)]:save('selected-'+name,'plane_diagnose',{'plane':'467e0b5d-3a91-4928-b51f-4c3fd5f5b95d','probe':{'x':x,'y':y},'limit':64})
save('selected','export_fabrication',{'output_dir':str(p/'fabrication/selected-foilfern')})
for side in ['top','bottom']:
 raw=call('render',{'target':'board','side':side,'width':1800,'height':1300})
 for c in raw['response']['result']['content']:
  if c['type']=='image':(p/('board-'+side+'.png')).write_bytes(base64.b64decode(c['data']))
 print('render',side,round(raw['seconds'],3),flush=True)
for tool in ['project_save','history','project_close']:save('selected',tool)
