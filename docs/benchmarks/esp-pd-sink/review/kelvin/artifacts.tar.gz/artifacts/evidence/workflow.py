import sys,json,shutil,base64
from pathlib import Path
sys.path.insert(0,'/workspace/esp-pd-sink')
from call import run,call,envelope
p=Path(__file__).parent
protected=['CC1','CC2','D+','D-','ANT','Net-(AE1-FEED)']
changed=['Net-(U6-Vin+)','Net-(U6-Vin-)','SDA','SCL']
def save(label,name,args=None):
 e=run(name,args);(p/f'{label}-{name}.json').write_text(json.dumps(e,indent=2));assert not e.get('error'),e;return e

def ref(label,layer,nets):return save(label,'reference_coverage',{'reference':{'signal_nets':nets,'reference_net':'GND','reference_layer':layer,'gap_limit':200}})
if __name__=='__main__' and sys.argv[1]=='control':
 ref('baseline-inner2','inner2',protected+changed)
 # Review all preview operations and their affected net before applying.
 r=json.load(open(p/'01-fixed-preview.json'))['response']['result']['structuredContent']['result']
 assert r['next_offset'] is None and r['validation']['acceptable'] and r['mutation_count']==2
 assert all(next(iter(m))=='Board' for m in r['mutations'])
 save('fixed','routing_apply',{'candidate':r['candidate'],'expected_revision':r['base_revision']})
 for tool in ['erc_run','drc_run','unrouted','board_get','project_save','history','project_close']:save('fixed',tool)
 shutil.copytree('/workspace/esp-pd-sink/u2-review/selected',p/'selected',ignore=shutil.ignore_patterns('output','*.lock','*.user.lp'))
 save('selected-open','project_open',{'path':str(p/'selected/ESP-PD-Sink.lpp')})
 for tool in ['project_summary','history','schematic_list','component_list','board_get']:save('selected-open',tool)
 r=json.load(open(p/'08-vcc-clearance-input.json'));r['expected_revision']=0
 save('selected','routing_copper_prepare',r)
