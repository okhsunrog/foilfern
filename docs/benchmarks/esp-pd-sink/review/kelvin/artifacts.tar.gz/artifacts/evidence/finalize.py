import json,sys,base64
from pathlib import Path
sys.path.insert(0,str(Path(__file__).parent));from workflow import p,save,ref,protected,changed,call,envelope
r=json.load(open(p/'final-inner1-routing_preview.json'))['result']
assert r['validation']['acceptable'] and r['next_offset'] is None and not r['stale'] and r['base_revision']==0
allowed={'RemoveNetSegment','AddNetSegment','AddNetSegmentElements','UpdateDevice'}
assert all(set(m['Board'])<=allowed for m in r['mutations'])
save('selected','routing_apply',{'candidate':r['candidate'],'expected_revision':r['base_revision']})
for tool in ['erc_run','drc_run','unrouted','board_get']:save('selected',tool)
for l in ['inner1','inner2']:ref('selected-'+l,l,protected+changed)
for label,plane,x,y in [('c19-ground','0e53fe96-8895-4f03-9f0a-ae0f9bbec798',129.1,-134.12),('u6-return','0e53fe96-8895-4f03-9f0a-ae0f9bbec798',122.8,-132.5),('r17-vbus','a582722c-38b4-4ccb-9bfc-e4c63df37075',121.015,-138.135),('j1-a9','a582722c-38b4-4ccb-9bfc-e4c63df37075',105.91,-138.52),('j1-b9','a582722c-38b4-4ccb-9bfc-e4c63df37075',105.91,-135.48)]:save('selected-'+label,'plane_diagnose',{'plane':plane,'probe':{'x':x,'y':y}})
save('selected','export_fabrication',{'output_dir':str(p/'fabrication/foilfern')})
for side in ['top','bottom']:
 raw=call('render',{'target':'board','side':side,'width':1800,'height':1300})
 for c in raw['response']['result']['content']:
  if c['type']=='image':(p/('board-'+side+'.png')).write_bytes(base64.b64decode(c['data']))
 print('render',side,round(raw['seconds'],3),flush=True)
for tool in ['project_save','history','project_close']:save('selected',tool)
