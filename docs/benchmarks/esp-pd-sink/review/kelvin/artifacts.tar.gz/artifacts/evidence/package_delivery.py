import json,shutil,hashlib,tarfile,subprocess,os,re
from pathlib import Path
p=Path(__file__).parent;repo=Path('/workspace/foilfern');docs=repo/'docs/benchmarks/esp-pd-sink/review/kelvin'
def copy(src,dest):dest.parent.mkdir(parents=True,exist_ok=True);shutil.copy2(src,dest)
for name in ['baseline-measurements.json','fixed-measurements.json','selected-measurements.json','geometry-comparison.json','reference-comparison.json','kelvin-comparison.json','fabrication-comparison.json','intent.json','baseline-region.png','fixed-region.png','selected-region.png','board-top.png','board-bottom.png','selected-input.json','plot_region.py']:copy(p/name,docs/name)
copy(p/'01-fixed-input.json',docs/'fixed-input.json')
s=(repo/'docs/benchmarks/esp-pd-sink/review/u2/measure_u2.py').read_text().replace('U2 review measurements','Kelvin review measurements').replace('measure_u2.py','measure_kelvin.py');(docs/'measure_kelvin.py').write_text(s)
root=p/'delivery/artifacts';root.mkdir(parents=True,exist_ok=True)
for name,src in [('input-u2',Path('/workspace/esp-pd-sink/u2-review/selected')),('fixed',p/'fixed'),('selected',p/'selected'),('paired-draft',p/'paired-draft')]:
 shutil.copytree(src,root/'native'/name,dirs_exist_ok=True,ignore=shutil.ignore_patterns('output','*.lock','*.user.lp'))
for f in p.iterdir():
 if f.is_file() and f.suffix in ['.json','.txt','.py','.png']:copy(f,root/'evidence'/f.name)
copy(docs/'measure_kelvin.py',root/'evidence/measure_kelvin.py');copy(repo/'docs/benchmarks/esp-pd-sink/review/measure.py',root/'evidence/measure.py')
shutil.copytree(p/'fabrication',root/'fabrication',dirs_exist_ok=True)
shutil.copytree(p/'paired-draft-evidence',root/'evidence/paired-draft',dirs_exist_ok=True)
for f in (p/'session').glob('*.json'):
 r=json.load(open(f))
 if r.get('request',{}).get('params',{}).get('name')!='render':copy(f,root/'session'/f.name)
for f in (p/'session').glob('*.stderr'):copy(f,root/'session'/f.name)
copy(docs/'REPORT.md',root/'REPORT.md')
manifest={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sorted(root.rglob('*')) if f.is_file() and f.name!='SHA256.json'}
(root/'SHA256.json').write_text(json.dumps(manifest,indent=2))
archive=docs/'artifacts.tar.gz'
with tarfile.open(archive,'w:gz') as t:t.add(root,arcname='artifacts')
verify=p/'delivery-verify';verify.mkdir(exist_ok=True)
with tarfile.open(archive) as t:t.extractall(verify,filter='data')
v=verify/'artifacts';assert all(hashlib.sha256((v/n).read_bytes()).hexdigest()==h for n,h in json.load(open(v/'SHA256.json')).items())
r=subprocess.run(['librepcb-cli','open-project','--erc','--drc',str(v/'native/selected/ESP-PD-Sink.lpp')],env=dict(os.environ,LIBREPCB_SUPPRESS_DEPRECATION_WARNINGS='1'),stdout=subprocess.PIPE,stderr=subprocess.STDOUT);(p/'delivery-reopen.txt').write_bytes(r.stdout);assert r.returncode==1
assert b'Non-approved messages: 12' in r.stdout and b'Non-approved messages: 0' in r.stdout
print('Verified',len(manifest),'archived files; reopened extracted selected native project; archive bytes',archive.stat().st_size)
# Validate every relative Markdown destination delivered in the report.
for link in re.findall(r'\]\(([^)]+)\)',(docs/'REPORT.md').read_text()):
 assert (docs/link).exists(),link
