import json
from pathlib import Path
p=Path(__file__).parent
r=json.load(open(p/'02-paired-input.json'))
def pt(x,y): return {'x':x,'y':y}
def t(a,z,layer='top',width=.2,points=()):
 d={'from':a,'to':z,'layer':layer,'width':width}
 if points:d['points']=[pt(*v) for v in points]
 return d
r['vias']=[v for v in r['vias'] if not v['label'].startswith('vbus')]
for label,net,x,y in [('sda-left','SDA',117.9,-132.1),('sda-right','SDA',123.1,-133.7),('scl-left','SCL',117.5,-134),('scl-right','SCL',123.15,-134.55)]:
 r['vias'].append({'label':label,'net':net,'position':pt(x,y),'drill':.3,'size':.6})
keep=[0,1,5,6,7,12,13]
r['traces']=[r['traces'][i] for i in keep]+[
 t('R17.4','1efc4dda-7c61-407c-a8da-af6bb8951d94',width=.6,points=[(119.3,-138.135),(119.3,-128.6),(122.35,-125.55)]),
 t('4061321c-d7d5-402f-aa75-3e50e4377906',{'via':'sda-left'}),
 t({'via':'sda-left'},{'via':'sda-right'},layer='bottom'),
 t({'via':'sda-right'},'U6.4',points=[(122.85,-133.8)]),
 t('2f7afee6-1833-41df-9f5f-3e03a0705a2e',{'via':'scl-left'},points=[(117.5,-133.6)]),
 t({'via':'scl-left'},{'via':'scl-right'},layer='bottom'),
 t({'via':'scl-right'},'U6.5'),
 t('U6.8','00ac50b2-e0ab-46bb-b604-ba73a6ad1e46',width=.25,points=[(127.35,-133.3),(128.65,-132)]),
 t({'via':'u6-vdd'},'U6.6',width=.25,points=[(126,-134.5),(126,-134.4)]),
 t({'via':'u6-vdd'},'C19.2',width=.4,points=[(126,-134.5),(126.45,-134.95),(128.1,-134.95)]),
 t('61a4e2b4-290f-4535-8064-77bf4d065e1a',{'via':'u6-vdd'},layer='inner2',width=.4,points=[(117.75,-132.9),(123.4,-132.9)])]
(p/'03-top-power-input.json').write_text(json.dumps(r,indent=2))
