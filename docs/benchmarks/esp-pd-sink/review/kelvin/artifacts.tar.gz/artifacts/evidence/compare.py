"""Compare accepted model geometry and trace-only Kelvin/power proxies."""
import json,math,sys,importlib.util
from pathlib import Path
sys.dont_write_bytecode=True
p=Path(__file__).parent
spec=importlib.util.spec_from_file_location('measure','/workspace/foilfern/docs/benchmarks/esp-pd-sink/review/measure.py');m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m)
def load(f):
 d=json.load(open(p/f))
 if 'response' in d:d=d['response']['result']['structuredContent']
 return d.get('result',d)
def dump(f,d):(p/f).write_text(json.dumps(d,indent=2))
def xy(d):return [d['x'],d['y']]
def stats(b):return {'segments':len(b['traces']),'vias':len(b['vias']),'trace_length_mm':sum(math.dist(xy(t['from']['position']),xy(t['to']['position'])) for t in b['traces'])}
def route(b,a,z):
 measure=m.measure(b,a,z);assert measure['status']=='measured'
 ts={t['uuid']:t for t in b['traces']};node=next(p['uuid'] for d in b['devices'] for p in d['pads'] if p['pad']==a);points=[]
 for id in measure['traces']:
  t=ts[id]
  def key(e):return e.get('pad_uuid') or e.get('via') or e.get('junction') or e.get('board_pad')
  start,end=(t['from'],t['to']) if key(t['from'])==node else (t['to'],t['from'])
  assert key(start)==node
  if not points:points.append(xy(start['position']))
  points.append(xy(end['position']));node=key(end)
 return points,measure

def proxy(b):
 a,plus=route(b,'R17.3','U6.10');z,minus=route(b,'R17.2','U6.9');poly=a+z[::-1]
 area=abs(sum(x*v-u*y for (x,y),(u,v) in zip(poly,poly[1:]+poly[:1])))/2
 return {'projected_loop_area_mm2':area,'plus_mm':plus['length_mm'],'minus_mm':minus['length_mm'],'plus_points_mm':a,'minus_points_mm':z,'scope':'Closed 2D centerline polygon between dedicated shunt sense pads and INA inputs; excludes barrels/internal paths; not an inductance/noise model.'}
if __name__=='__main__':
 a=load('baseline-board_get.json');s=load('selected-board_get.json');c=load('fixed-board_get.json');r=json.load(open(p/'08-vcc-clearance-input.json'))
 out={name:stats(b) for name,b in [('baseline',a),('fixed',c),('selected',s)]}
 for field,removal in [('traces','remove_traces'),('vias','remove_vias')]:
  aa={v['uuid']:v for v in a[field]};ss={v['uuid']:v for v in s[field]};removed=sorted(aa.keys()-ss.keys());added=sorted(ss.keys()-aa.keys());assert removed==sorted(r[removal])
  def norm(t):return {k:v for k,v in t.items() if k!='segment'}
  assert all(norm(aa[k])==norm(ss[k]) for k in aa.keys()&ss.keys())
  out[field]={'removed':removed,'added':added,'retained_geometry_preserved':True}
 da={d['designator']:d for d in a['devices']};ds={d['designator']:d for d in s['devices']};out['placements']=[]
 for name,d in da.items():
  if name not in ['U6','C19']:assert d==ds[name],name
  elif d!=ds[name]:out['placements'].append({'designator':name,'before':{k:d[k] for k in ['position','rotation','side']},'after':{k:ds[name][k] for k in ['position','rotation','side']}})
 for field in ['copper_layers','holes','other_polygons','outlines','polygons','thickness','zones']:assert a[field]==s[field],field
 assert [{k:v for k,v in d.items() if k!='fragments'} for d in a['planes']]==[{k:v for k,v in d.items() if k!='fragments'} for d in s['planes']]
 out['mechanical_and_plane_settings_preserved']=True
 original=Path('/workspace/esp-pd-sink/u2-review/selected/circuit/circuit.lp').read_bytes()
 out['netlist_byte_identical']=all((p/n/'circuit/circuit.lp').read_bytes()==original for n in ['fixed','selected']);assert out['netlist_byte_identical']
 out['drc_messages_identical']=all(load(n+'-drc_run.json')['messages']==load('baseline-drc_run.json')['messages'] for n in ['fixed','selected']);assert out['drc_messages_identical']
 dump('geometry-comparison.json',out)
 pr={n:proxy(b) for n,b in [('baseline',a),('fixed',c),('selected',s)]}
 ids={'75ef8cfd-5831-4699-9bb4-fdb5b96b7721','38cc9ffc-bb38-462b-9932-27b399322c0a','5a4fdd6e-3fb5-44f1-b0a2-0a61aee2a96b','de166d6f-8287-4146-b439-593e131483eb','2202df4d-0d97-4052-81cc-473773a38a34','761c9649-3add-4db6-bc68-e5e2c422297b'}
 old=[t for t in a['traces'] if t['uuid'] in ids];new=[t for t in s['traces'] if t['net']=='VBUS' and t['uuid'] in out['traces']['added']]
 assert len(old)==6 and len(new)==4
 def branch(ts):return {'length_mm':sum(math.dist(xy(t['from']['position']),xy(t['to']['position'])) for t in ts),'widths_mm':sorted({t['width'] for t in ts}),'sum_length_over_width':sum(math.dist(xy(t['from']['position']),xy(t['to']['position']))/t['width'] for t in ts),'layers':sorted({t['layer'] for t in ts})}
 pr['vbus_replaced_section']={'baseline':branch(old),'selected':branch(new),'scope':'Uniform-thickness rectangular-trace resistance proxy only; no copper thickness, pour current sharing, thermal or current rating asserted.'}
 dump('kelvin-comparison.json',pr)
 # Measure impacted digital paths to U2 and local decoupling by explicit pads.
 paths=[('U6.4','U2.7'),('U6.5','U2.6'),('U6.6','C19.2'),('U6.7','C19.1')]
 for n,b in [('baseline',a),('fixed',c),('selected',s)]:
  extra={a+'-'+z:m.measure(b,a,z) for a,z in paths};dump(n+'-local-paths.json',extra)
 print(json.dumps({k:v for k,v in out.items() if k in ['baseline','fixed','selected']},indent=2));print(json.dumps(pr,indent=2))
