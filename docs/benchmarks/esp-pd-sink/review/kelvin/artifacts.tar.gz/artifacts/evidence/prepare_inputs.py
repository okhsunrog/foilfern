import json
from pathlib import Path
p=Path(__file__).parent
b=json.load(open(p/'baseline-board_get.json'))['result']
sense_nets={'Net-(U6-Vin+)','Net-(U6-Vin-)'}
minus=[t['uuid'] for t in b['traces'] if t['net']=='Net-(U6-Vin-)']
control={'remove_traces':minus,'traces':[{'from':'R17.2','to':'U6.9','layer':'top','width':0.2,'points':[{'x':124.2,'y':-133.5},{'x':124.2,'y':-132.6},{'x':125.3,'y':-131.5}]}]}
(p/'01-fixed-input.json').write_text(json.dumps(control,indent=2))
remove={t['uuid'] for t in b['traces'] if t['net'] in sense_nets}
# Explicitly replace U6/C19 attachments and their local fanouts.
for t in b['traces']:
 if any(t[e].get('pad','').split('.')[0] in ['U6','C19'] for e in ['from','to']):remove.add(t['uuid'])
remove.update(['2202df4d-0d97-4052-81cc-473773a38a34','38cc9ffc-bb38-462b-9932-27b399322c0a','5a4fdd6e-3fb5-44f1-b0a2-0a61aee2a96b','761c9649-3add-4db6-bc68-e5e2c422297b','de166d6f-8287-4146-b439-593e131483eb','75ef8cfd-5831-4699-9bb4-fdb5b96b7721','ad12d33c-2afa-4ceb-9925-02635bfb85ba','fad1e032-c864-48da-806b-e4d68d7f93b0','2753e47c-701e-4141-93c3-80e00bff6887','f8ba6cbb-727d-4124-9626-32a11d1fc6eb','d647fba4-e590-48b2-947d-563b2952e632','da3055d2-97eb-4e15-adbb-0093d6a526b6','95cd7709-4cec-4c3b-82b3-d3745312e16b','b3bc2d0e-501d-4714-9392-b5678eeedded','c1f91c08-fd60-4766-94cc-361fb55a1ff1','d909aedd-801b-430a-a672-cc5a54b32f09','ded03d6a-5cbe-4ff2-83d4-c6d7851733b7','cece3a45-92eb-4ec7-94a0-010f01b7540e','f973afde-8e66-4e15-9e9d-c9562ea707f5','fb571d1b-d936-48cd-bdb1-ac59be2d86f7','fb6c02b2-84e7-485e-9ad3-ac340bce6cdd','4a603a32-c815-4171-88b6-c61f25cf1b31'])
actual={t['uuid'] for t in b['traces']};assert remove<=actual,remove-actual
vias=[{'label':'vbus-lower','net':'VBUS','position':{'x':119.0,'y':-137.8},'drill':0.4,'size':0.8},{'label':'vbus-upper','net':'VBUS','position':{'x':123.15,'y':-130.0},'drill':0.4,'size':0.8},{'label':'u6-vdd','net':'VCC','position':{'x':124.8,'y':-134.5},'drill':0.3,'size':0.6},{'label':'c19-ground','net':'GND','position':{'x':129.1,'y':-134.12},'drill':0.3,'size':0.6}]
def pt(x,y):return {'x':x,'y':y}
def trace(a,z,layer='top',width=0.2,points=None,net=None):
 t={'from':a,'to':z,'layer':layer,'width':width}
 if points:t['points']=[pt(x,y) for x,y in points]
 if net:t['net']=net
 return t
traces=[trace('R17.3','U6.10',points=[(121.3,-135.5),(123.75,-135.5),(123.75,-133.75),(125.2,-132.3)]),trace('R17.2','U6.9',points=[(126.7,-135.5),(124.2,-135.5),(124.2,-133.9),(125.3,-132.8)]),trace('R17.4',{'via':'vbus-lower'},width=0.4),trace({'via':'vbus-lower'},{'via':'vbus-upper'},layer='bottom',width=0.4),trace({'via':'vbus-upper'},'1efc4dda-7c61-407c-a8da-af6bb8951d94',width=0.4),trace('U6.2','3ac3f7e5-314f-4a64-b06f-27b4188d61d1'),trace('U6.1','U6.2'),trace('U6.3','e9f8a19d-a2ba-4b4b-9747-b32ac8e94e72',points=[(120.5,-133.3),(120.0,-132.8),(120.0,-131.55)]),trace('4061321c-d7d5-402f-aa75-3e50e4377906','U6.4',points=[(118.65,-133.35),(119.1,-133.8)]),trace('2f7afee6-1833-41df-9f5f-3e03a0705a2e','U6.5',points=[(118.2,-133.8),(118.7,-134.3)]),trace('U6.8',pt(127.35,-133.3),width=0.25),trace(pt(127.35,-133.3),'00ac50b2-e0ab-46bb-b604-ba73a6ad1e46',width=0.4,points=[(128.65,-132.0)]),trace('U6.7','C19.1',points=[(126.15,-133.75),(127.8,-133.75),(128.1,-134.05)]),trace('C19.1',{'via':'c19-ground'},width=0.4),trace({'via':'u6-vdd'},pt(126,-134.5),width=0.4),trace(pt(126,-134.5),'U6.6',width=0.25,points=[(126,-134.4)]),trace(pt(126,-134.5),'C19.2',width=0.4,points=[(126.45,-134.95),(128.1,-134.95)]),trace('61a4e2b4-290f-4535-8064-77bf4d065e1a',{'via':'u6-vdd'},layer='inner2',width=0.4)]
request={'placements':[{'component':'U6','position':pt(124,-133.3)},{'component':'C19','position':pt(128.4,-134.6)}],'remove_traces':sorted(remove),'remove_vias':[v['uuid'] for v in b['vias'] if v['net'] in sense_nets]+['cde7681d-ea71-450c-b5ca-5ef7832adc66','4a0c2ac6-66bc-4135-83cf-139226069e02'],'vias':vias,'traces':traces}
(p/'02-paired-input.json').write_text(json.dumps(request,indent=2))
print('Control and paired requests saved;',len(remove),'selected trace replacements.')
