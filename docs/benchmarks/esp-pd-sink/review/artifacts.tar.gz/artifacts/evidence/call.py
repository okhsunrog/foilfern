import json
import socket
import os
import sys

def call(name, args=None, method='tools/call'):
    params = {'name': name, 'arguments': args or {}} if method == 'tools/call' else args or {}
    with socket.socket(socket.AF_UNIX) as connection:
        connection.connect('/workspace/esp-pd-sink/' + os.environ.get('MCP_SOCKET', 'mcp.sock'))
        connection.sendall(json.dumps({'method': method, 'params': params}).encode() + b'\n')
        result = json.loads(connection.makefile().readline())
    return result

def envelope(record):
    result = record['response'].get('result', {})
    return result.get('structuredContent') or json.loads(result['content'][0]['text'])

def run(name, args=None):
    record = call(name, args)
    value = envelope(record)
    print(name, round(record['seconds'], 3), value.get('outcome'), flush=True)
    if value.get('error'):
        print(value, flush=True)
    return value

if __name__ == '__main__':
    args = json.loads(sys.argv[2]) if len(sys.argv) > 2 else {}
    print(json.dumps(call(sys.argv[1], args), indent=2))
