"""Fresh-process MCP timing and Linux process high-water memory measurement."""
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys
import time

root = Path('/workspace/esp-pd-sink')
kind = sys.argv[1]
folder = root / f'benchmark-{kind}'
shutil.copytree(root / 'foilfern', folder, dirs_exist_ok=True)
out = root / f'benchmark-{kind}.json'
log = open(root / f'benchmark-{kind}.stderr', 'w')
env = dict(os.environ, RUST_LOG='librepcb_core::project::board::drc=debug')
proc = subprocess.Popen(['/workspace/foilfern/target/debug/librepcb-mcp', '--project', str(folder / 'ESP-PD-Sink.lpp')], stdin=subprocess.PIPE, stdout=subprocess.PIPE, stderr=log, text=True, bufsize=1, env=env)
sequence = 0
records = []
def rpc(method, params):
    global sequence
    sequence += 1
    start = time.perf_counter()
    proc.stdin.write(json.dumps({'jsonrpc':'2.0','id':sequence,'method':method,'params':params}) + '\n');proc.stdin.flush()
    while True:
        reply = json.loads(proc.stdout.readline())
        if reply.get('id') == sequence:break
    memory = {line.split(':')[0]:line.split(':')[1].strip() for line in Path(f'/proc/{proc.pid}/status').read_text().splitlines() if line.startswith(('VmHWM:', 'VmRSS:'))}
    record = {'method':method,'params':params,'seconds':time.perf_counter()-start,'memory':memory,'response':reply}
    records.append(record);out.write_text(json.dumps(records, indent=2))
    print(params.get('name',method), round(record['seconds'],3), memory, flush=True)
    return reply.get('result',{}).get('structuredContent', {})
def call(name, args=None):return rpc('tools/call',{'name':name,'arguments':args or {}})
rpc('initialize',{'protocolVersion':'2024-11-05','capabilities':{},'clientInfo':{'name':'handoff-benchmark','version':'1'}})
proc.stdin.write(json.dumps({'jsonrpc':'2.0','method':'notifications/initialized'})+'\n');proc.stdin.flush()
for t in ['server_info','project_summary','history','schematic_list','component_list','board_get']:call(t)
call('planes_rebuild')
call('unrouted')
args=json.loads((root / ('oled-04-input.json' if kind=='oled' else 'builtin-input.json')).read_text())
r=call('routing_copper_prepare' if kind=='oled' else 'routing_region_prepare',args)
assert r['result']['validation']['acceptable'],r
candidate=r['result']['candidate']
p=call('routing_preview',{'candidate':candidate})
assert not p['result']['stale'] and p['result']['next_offset'] is None
r=call('routing_apply',{'candidate':candidate})
assert r['result']['applied'] and r['result']['validation']['acceptable'],r
call('board_get');call('project_save');call('project_close')
proc.stdin.close();proc.wait(timeout=10);log.close()
