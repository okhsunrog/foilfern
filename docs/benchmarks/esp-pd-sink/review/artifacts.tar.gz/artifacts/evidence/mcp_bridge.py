"""Single-session stdio MCP bridge; saves exact requests, replies and timings."""
import json
import pathlib
import os
import socketserver
import subprocess
import sys
import time

ROOT = pathlib.Path('/workspace/esp-pd-sink')
LOG = ROOT / os.environ.get('MCP_LOG', 'session')
LOG.mkdir(exist_ok=True)
proc = subprocess.Popen(
    ['/workspace/foilfern/target/debug/librepcb-mcp', '--project', sys.argv[1]],
    stdin=subprocess.PIPE, stdout=subprocess.PIPE,
    stderr=open(LOG / 'server.stderr', 'a'), text=True, bufsize=1,
)
sequence = 0

def rpc(method, params):
    global sequence
    sequence += 1
    message = {'jsonrpc': '2.0', 'id': sequence, 'method': method, 'params': params}
    start = time.perf_counter()
    proc.stdin.write(json.dumps(message) + '\n')
    proc.stdin.flush()
    while True:
        line = proc.stdout.readline()
        if not line:
            raise RuntimeError(f'MCP exited: {proc.poll()}')
        reply = json.loads(line)
        if reply.get('id') == sequence:
            break
    record = {'request': message, 'response': reply, 'seconds': time.perf_counter() - start}
    (LOG / f'{sequence:04d}-{method.replace("/", "_")}.json').write_text(json.dumps(record, indent=2))
    return record

rpc('initialize', {'protocolVersion': '2024-11-05', 'capabilities': {}, 'clientInfo': {'name': 'handoff-review', 'version': '1'}})
proc.stdin.write(json.dumps({'jsonrpc': '2.0', 'method': 'notifications/initialized'}) + '\n')
proc.stdin.flush()

class Handler(socketserver.StreamRequestHandler):
    def handle(self):
        try:
            request = json.loads(self.rfile.readline())
            result = rpc(request.get('method', 'tools/call'), request['params'])
        except Exception as error:
            result = {'error': str(error)}
        self.wfile.write(json.dumps(result).encode() + b'\n')

path = str(ROOT / os.environ.get('MCP_SOCKET', 'mcp.sock'))
pathlib.Path(path).unlink(missing_ok=True)
with socketserver.UnixStreamServer(path, Handler) as server:
    print('MCP bridge ready', flush=True)
    server.serve_forever()
